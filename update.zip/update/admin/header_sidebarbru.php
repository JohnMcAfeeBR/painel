<?php if (count(get_included_files()) == 1) { exit; } ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <title>Xtream Brutus</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="robots" content="noindex,nofollow">
        <link rel="shortcut icon" href="assets/images/favicon.ico">
        <link href="assets/libs/jquery-nice-select/nice-select.css" rel="stylesheet" type="text/css" />
        <link href="assets/libs/switchery/switchery.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/libs/select2/select2.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/libs/datatables/dataTables.bootstrap4.css" rel="stylesheet" type="text/css" />
        <link href="assets/libs/datatables/responsive.bootstrap4.css" rel="stylesheet" type="text/css" />
        <link href="assets/libs/datatables/buttons.bootstrap4.css" rel="stylesheet" type="text/css" />
        <link href="assets/libs/datatables/select.bootstrap4.css" rel="stylesheet" type="text/css" />
        <link href="assets/libs/jquery-toast/jquery.toast.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/libs/bootstrap-select/bootstrap-select.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/libs/bootstrap-touchspin/jquery.bootstrap-touchspin.css" rel="stylesheet" type="text/css" />
        <link href="assets/libs/treeview/style.css" rel="stylesheet" type="text/css" />
        <link href="assets/libs/clockpicker/bootstrap-clockpicker.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/libs/daterangepicker/daterangepicker.css" rel="stylesheet" type="text/css" />
        <link href="assets/libs/nestable2/jquery.nestable.min.css" rel="stylesheet" />
        <link href="assets/libs/magnific-popup/magnific-popup.css" rel="stylesheet" type="text/css" />
        <link href="assets/libs/bootstrap-colorpicker/bootstrap-colorpicker.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css" />
		<?php if (!$rAdminSettings["dark_mode"]) { ?>
        <link href="assets/css/app_sidebarbru.css" rel="stylesheet" type="text/css" />
		<link href="assets/css/bootstrapbru.css" rel="stylesheet" type="text/css" />
		<?php } else { ?>
		<link href="assets/css/app_sidebar.dark.css" rel="stylesheet" type="text/css" />
		<link href="assets/css/bootstrap.dark.css" rel="stylesheet" type="text/css" />
		<?php } ?>
    </head>
        <script src="assets/js/sweetalert.min.js"></script>

    <body class="<?php if (!$rAdminSettings["dark_mode"]) { echo "topbar-dark left-side-menu-light "; } ?><?php if (!$rAdminSettings["expanded_sidebar"]) { echo 'enlarged" data-keep-enlarged="true"'; } else { echo '"' ;} ?>>
 
 <!-- Begin page -->
</style>

        <div id="wrapper">


            <!-- Topbar Start -->
            <div class="navbar-custom">
                <ul class="list-unstyled topnav-menu float-right mb-0">
					<li class="notification-list username">
						<a class="nav-link text-white waves-effect" href="./edit_profile.php" role="button" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="<?=$_["edit_profile"]?>">
							<?=$rUserInfo["username"]?>
						</a>
					</li>
                    <?php if (($rServerError) && ($rPermissions["is_admin"]) && (hasPermissions("adv", "servers"))) { ?>
                    <li class="notification-list">
                        <a href="./servers.php" class="nav-link right-bar-toggle waves-effect text-warning">
                            <i class="mdi mdi-wifi-strength-off noti-icon"></i>
                        </a>
                    </li>
                    <?php } ?>
                    <?php if ($rPermissions["is_reseller"]) { ?>
                    <li class="notification-list">
                        <a class="nav-link text-white waves-effect" href="#" role="button">
                            <i class="mdi mdi-coins noti-icon"></i>
                            <?php if (floor($rUserInfo["credits"]) == $rUserInfo["credits"]) {
                                echo number_format($rUserInfo["credits"], 0);
                            } else {
                                echo number_format($rUserInfo["credits"], 2);
                            } ?>
                        </a>
                    </li>
                    <?php }
                    if ($rPermissions["is_admin"]) {
					if ((hasPermissions("adv", "settings")) OR (hasPermissions("adv", "database")) OR (hasPermissions("adv", "block_ips")) OR (hasPermissions("adv", "block_isps")) OR (hasPermissions("adv", "block_uas")) OR (hasPermissions("adv", "categories")) OR (hasPermissions("adv", "channel_order")) OR (hasPermissions("adv", "epg")) OR (hasPermissions("adv", "folder_watch")) OR (hasPermissions("adv", "mng_groups")) OR (hasPermissions("adv", "mass_delete")) OR (hasPermissions("adv", "mng_packages")) OR (hasPermissions("adv", "process_monitor")) OR (hasPermissions("adv", "rtmp")) OR (hasPermissions("adv", "subresellers")) OR (hasPermissions("adv", "tprofiles"))) { ?>
                    <li class="dropdown notification-list">
					<?php if ((hasPermissions("adv", "settings")) OR (hasPermissions("adv", "database"))) { ?>
                        <a class="nav-link dropdown-toggle nav-user mr-0 waves-effect text-white" href="./settings.php" role="button" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="<?=$_["settings"]?>">
                            <i class="fe-settings noti-icon"></i>
                        </a>
					<?php } ?>
                    </li>
                    <?php }
					} ?>
                    <li class="notification-list">
                        <a href="./logout.php" class="nav-link right-bar-toggle waves-effect text-white" role="button" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Logout">
                            <i class="fe-power noti-icon"></i>
                        </a>
                    </li>
                </ul>
                <!-- LOGO -->
                <div class="logo-box">
                    <a href="<?php if ($rPermissions["is_admin"]) { ?>dashboard.php<?php } else { ?>reseller.php<?php } ?>" class="logo text-center">
                        <span class="logo-lg">
                            <img src="assets/images/logo.png" alt="" height="55">
                        </span>
                        <span class="logo-sm">
                            <img src="assets/images/logo-sm.png" alt="" height="55">
                        </span>
                    </a>
                </div>

                <ul class="list-unstyled topnav-menu topnav-menu-left m-0">
                    <li>
                        <button class="button-menu-mobile waves-effect text-white">
                            <span></span>
                            <span></span>
                            <span></span>
                        </button>
                    </li>
                </ul>
            </div>
            <!-- end Topbar -->
            <!-- ========== Left Sidebar Start ========== -->
            <div class="left-side-menu">
                <div class="slimscroll-menu">
                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <ul class="metismenu" id="side-menu">
                            <li>
							    <a href="#"><span>Main</span><span class="arrow-right"></span></a>
                                <a href="./<?php if ($rPermissions["is_admin"]) { ?>dashboard.php<?php } else { ?>reseller.php<?php } ?>" style="padding-left:12%; font-size:15px;"><i class="fas fa-tachometer-alt"></i><span><?=$_["dashboard"]?></span></a>
                                   <?php
									if (hasPermissions("adv", "live_connections")) { ?>
                                    <a href="./live_connections.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-satellite-dish"></i><span><?=$_["live_connections"]?></span></a>
									<?php }
									if (hasPermissions("adv", "connection_logs")) { ?>
                                    <a href="./user_ips.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-chalkboard"></i><span>Line IP Usage</span></a>
									</li>
		                            <?php }
                                    if (($rPermissions["is_admin"]) && (hasPermissions("adv", "manage_tickets"))) { ?>
                                    <li>
                                        <a href="./tickets.php" style="padding-left:12%; font-size:15px;"><i class="far fa-envelope-open"></i><span><?=$_["tickets"]?></span></a>
                                    </li>
                                    <?php }
                                    if ($rPermissions["is_reseller"]) { ?>
                                    <li>
                                   <a href="#"><span><?=$_["support"]?></span><span class="arrow-right"></span></a>
                                    <a href="./ticket.php" style="padding-left:12%; font-size:15px;"><i class="	fas fa-paper-plane"></i><span><?=$_["create_ticket"]?></a>
                                    <a href="./tickets.php" style="padding-left:12%; font-size:15px;"><i class="far fa-envelope-open"></i><span><?=$_["manage_tickets"]?></a>
                                    </li>

									<?php } ?>
                                    <?php if (($rPermissions["is_reseller"]) && ($rPermissions["reseller_client_connection_logs"])) { ?>
                                    <li>
						        		<a href="#"><span><?=$_["connections"]?></span><span class="arrow-right"></span></a>
                                    <li><a href="./live_connections.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-satellite-dish"></i><span><?=$_["live_connections"]?></a></li>
                                    <li><a href="./user_activity.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-info"></i><span><?=$_["activity_logs"]?></a></li>
                            </li>
                            <?php }
                            if ($rPermissions["is_admin"]) {
							if ((hasPermissions("adv", "servers")) OR (hasPermissions("adv", "add_server")) OR (hasPermissions("adv", "live_connections")) OR (hasPermissions("adv", "connection_logs"))) { ?>
                            <li>
                                <a href="#"><span><?=$_["servers"]?></span><span class="arrow-right"></span></a>
									<?php if (hasPermissions("adv", "add_server")) { ?>
                                    <li><a href="./server.php"  style="padding-left:12%; font-size:15px;"><i class="fas fa-plus"></i><span><?=$_["add_existing_lb"]?></span></a></li>
                                    <li><a href="./install_server.php" style="padding-left:12%; font-size:15px;"><i class="far fa-calendar-plus"></i><span><?=$_["install_load_balancer"]?></span></a></li>
                                    <li><a href="./install_serverssl.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-calendar-plus"></i><span>Install ssl Balancer</span></a></li>
									<?php }
									if (hasPermissions("adv", "servers")) { ?>
                                    <li><a href="./servers.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-server"></i><span><?=$_["manage_servers"]?></span></a></li>
									<?php } ?>
                            </li>
                            <?php }
							if ((hasPermissions("adv", "add_user")) OR (hasPermissions("adv", "users")) OR (hasPermissions("adv", "mass_edit_users")) OR (hasPermissions("adv", "mng_regusers")) OR (hasPermissions("adv", "add_reguser")) OR (hasPermissions("adv", "credits_log")) OR (hasPermissions("adv", "client_request_log")) OR (hasPermissions("adv", "reg_userlog"))) { ?>
							<li>
                                <a href="#"><span>Lines</span><span class="arrow-right"></span></a>
									<?php if (hasPermissions("adv", "add_user")) { ?>
                                    <li><a href="./user.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-plus"></i><span>Add Line</span></a></li>
									<?php }
									if (hasPermissions("adv", "users")) { ?>
                                    <li><a href="./users.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-user-friends"></i><span>Manage Lines</span></a></li>
									<?php }
									if (hasPermissions("adv", "mass_edit_users")) { ?>
                                    <li><a href="./user_mass.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-layer-group"></i><span>Mass Edit Lines</span></a></li>
									</li>
									<?php } ?>
							<?php }
							} else { ?>
							<li>
                                <a href="#"><span><?=$_["users"]?></span><span class="arrow-right"></span></a>
                                    <?php if ((!$rAdminSettings["disable_trial"]) && ($rPermissions["total_allowed_gen_trials"] > 0) && ($rUserInfo["credits"] >= $rPermissions["minimum_trial_credits"])) { ?>
                                    <li><a href="./user_reseller.php?trial" style="padding-left:12%; font-size:15px;"><i class="fab fa-earlybirds"></i><span><?=$_["generate_trial"]?></span></a></li>
                                    <?php } ?>
                                    <li><a href="./user_reseller.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-plus"></i><span><?=$_["add_user"]?></span></a></li>
                                    <li><a href="./users.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-user-friends"></i><span><?=$_["manage_users"]?></span></a></li>
                            </li>
                            <?php }
							if ($rPermissions["is_admin"]) {
							if ((hasPermissions("adv", "add_mag")) OR (hasPermissions("adv", "manage_mag")) OR (hasPermissions("adv", "add_e2")) OR (hasPermissions("adv", "manage_e2")) OR (hasPermissions("adv", "manage_events"))) { ?>
                            <li>
                                <a href="#"><span>Mags</span><span class="arrow-right"></span></a>
									<?php if (hasPermissions("adv", "add_mag")) { ?>
                                    <li><a href="./user.php?mag" style="padding-left:12%; font-size:15px;"><i class="fas fa-plus"></i><span><?=$_["add_mag"]?></span></a></li>
                                    <li><a href="./mag.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-american-sign-language-interpreting"></i><span><?=$_["link_mag"]?></span></a></li>
									<?php }
									if (hasPermissions("adv", "manage_mag")) { ?>
                                    <li><a href="./mags.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-user-friends"></i><span><?=$_["manage_mag_devices"]?></span></a></li>
									<?php } ?>
									 </li>
									<li>
                                    <a href="#"><span>Enigma</span><span class="arrow-right"></span></a>
                                   <?php 
									if (hasPermissions("adv", "add_e2")) { ?>
                                    <li><a href="./user.php?e2" style="padding-left:12%; font-size:15px;"><i class="fas fa-plus"></i><span><?=$_["add_enigma"]?></span></a></li>
                                    <li><a href="./enigma.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-american-sign-language-interpreting"></i><span><?=$_["link_enigma"]?></span></a></li>
									<?php }
									if (hasPermissions("adv", "manage_e2")) { ?>
                                    <li><a href="./enigmas.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-user-friends"></i><span><?=$_["manage_enigma_devices"]?></span></a></li>
									<?php } ?>
                            </li>
							<?php }
							} else { ?>
							<li>
                                <a href="#"><span><?=$_["devices"]?></span><span class="arrow-right"></span></a>
                                    <li><a href="./mags.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-user-friends"></i><span><?=$_["manage_mag_devices"]?></span></a></li>
                                    <li><a href="./enigmas.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-user-friends"></i><span><?=$_["manage_enigma_devices"]?></span></a></li>
                            </li>
							<?php }
							if ((hasPermissions("adv", "add_stream")) OR (hasPermissions("adv", "import_streams")) OR (hasPermissions("adv", "create_channel")) OR (hasPermissions("adv", "streams")) OR (hasPermissions("adv", "mass_edit_streams"))  OR (hasPermissions("adv", "stream_tools"))  OR (hasPermissions("adv", "stream_errors"))  OR (hasPermissions("adv", "fingerprint"))) { ?>
                            <li>
                                <a href="#"><span><?=$_["streams"]?></span><span class="arrow-right"></span></a>
									<?php if (hasPermissions("adv", "add_stream")) { ?>
                                    <li><a href="./stream.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-plus"></i><span><?=$_["add_stream"]?></span></a></li>
									<?php }
									if (hasPermissions("adv", "import_streams")) { ?>
                                    <li><a href="./stream.php?import" style="padding-left:12%; font-size:15px;"><i class="far fa-handshake"></i><span><?=$_["import_streams"]?></span></a></li>
									<?php }
									if (hasPermissions("adv", "streams")) { ?>
                                    <li><a href="./streams.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-tv"></i><span><?=$_["manage_streams"]?></span></a></li>
									<?php }
									if (hasPermissions("adv", "mass_edit_streams")) { ?>
                                    <li><a href="./stream_mass.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-layer-group"></i><span><?=$_["mass_edit_streams"]?></span></a></li>
									<?php }
									if (hasPermissions("adv", "stream_tools")) { ?>
									<li><a href="./stream_tools.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-atom"></i><span><?=$_["stream_tools"]?></span></a></li>
									<?php }
									if (hasPermissions("adv", "create_channel")) { ?>
                                    <li><a href="./created_channel.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-tv"></i><span><?=$_["create_channel"]?></span></a></li>
									<?php }
									if (hasPermissions("adv", "fingerprint")) { ?>
                                    <li><a href="./fingerprint.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-paw"></i><span><?=$_["fingerprint"]?></span></a></li>
									<?php } ?>
                            </li>
							<?php }
                            if (($rPermissions["is_reseller"]) && ($rPermissions["create_sub_resellers"])) { ?>
                            <li>
                                <a href="#"><span><?=$_["subresellers"]?></span><span class="arrow-right"></span></a>
                                    <?php if ($rPermissions["is_admin"]) { ?>
                                    <li><a href="./reg_user.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-plus"></i><span><?=$_["add_subreseller"]?></span></a></li>
                                    <?php } else { ?>
                                    <li><a href="./subreseller.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-plus"></i><span><?=$_["add_subreseller"]?></span></a></li>
                                    <?php } ?>
                                    <li><a href="./reg_users.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-users"></i><span><?=$_["manage_subresellers"]?></span></a></li>
                            </li>
                            <?php }
							if ($rPermissions["is_admin"]) {
							if ((hasPermissions("adv", "add_movie")) OR (hasPermissions("adv", "import_movies")) OR (hasPermissions("adv", "movies")) OR (hasPermissions("adv", "series")) OR (hasPermissions("adv", "add_series")) OR (hasPermissions("adv", "mass_sedits_vod")) OR (hasPermissions("adv", "mass_sedits"))) { ?>
                            <li>
                                <a href="#"><span>Movies</span><span class="arrow-right"></span></a>
									<?php if (hasPermissions("adv", "add_movie")) { ?>
									<li><a href="./movie.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-plus"></i><span><?=$_["add_movie"]?></span></a></li>
									<?php }
									if (hasPermissions("adv", "import_movies")) { ?>
									<li><a href="./movie.php?import" style="padding-left:12%; font-size:15px;"><i class="fas fa-download"></i><span><?=$_["import_movies"]?></span></a></li>
									<?php }
									if (hasPermissions("adv", "movies")) { ?>
									<li><a href="./movies.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-sliders-h"></i><span><?=$_["manage_movies"]?></span></a></li>
									<?php }
									if (hasPermissions("adv", "mass_sedits_vod")) { ?>
									<li><a href="./movie_mass.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-folder-open"></i><span><?=$_["mass_edit_movies"]?></span></a></li>
									<?php } ?>
									 </li>
									<li>
                                    <a href="#"><span>Series</span><span class="arrow-right"></span></a>
                                   <?php  if (hasPermissions("adv", "add_series")) { ?>
									<li><a href="./serie.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-plus"></i><span><?=$_["add_series"]?></span></a></li>
									<?php }
									if (hasPermissions("adv", "series")) { ?>
									<li><a href="./series.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-sliders-h"></i><span><?=$_["manage_series"]?></span></a></li>
									<?php }
									if (hasPermissions("adv", "episodes")) { ?>
									<li><a href="./episodes.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-cubes"></i><span><?=$_["manage_episodes"]?></span></a></li>
									<?php }
									if (hasPermissions("adv", "mass_sedits")) { ?>
									<li><a href="./series_mass.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-sitemap"></i><span><?=$_["mass_edit_series"]?></span></a></li>
                                    <li><a href="./episodes_mass.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-project-diagram"></i><span><?=$_["mass_edit_episodes"]?></span></a></li>
									<?php } ?>
                            </li>
							<?php }
							if ((hasPermissions("adv", "add_radio")) OR (hasPermissions("adv", "radio")) OR (hasPermissions("adv", "mass_edit_radio"))) { ?>
                            <li>
                                <a href="#"><span><?=$_["stations"]?></span><span class="arrow-right"></span></a>
									<?php if (hasPermissions("adv", "add_radio")) { ?>
									<li><a href="./radio.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-plus"></i><span><?=$_["add_station"]?></span></a></li>
									<?php }
									if (hasPermissions("adv", "radio")) { ?>
									<li><a href="./radios.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-file-audio"></i><span><?=$_["manage_stations"]?></span></a></li>
									<?php } ?>
									<?php if (hasPermissions("adv", "mass_edit_radio")) { ?>
									<li><a href="./radio_mass.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-sliders-h"></i><span><?=$_["mass_edit_stations"]?></span></a></li>
									<?php } ?>
                            </li>
							<?php }
							if ((hasPermissions("adv", "add_bouquet")) OR (hasPermissions("adv", "bouquets"))) { ?>
                            <li>
                                <a href="#"><span><?=$_["bouquets"]?></span><span class="arrow-right"></span></a>
									<?php if (hasPermissions("adv", "add_bouquet")) { ?>
                                    <li><a href="./bouquet.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-plus"></i><span><?=$_["add_bouquet"]?></span></a></li>
									<?php }
									if (hasPermissions("adv", "bouquets")) { ?>
                                    <li><a href="./bouquets.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-list-ul"></i><span><?=$_["manage_bouquets"]?></span></a></li>
                                    <?php }
									if (hasPermissions("adv", "edit_bouquet")) { ?>
                                    <li><a href="./bouquet_sort.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-building"></i><span><?=$_["order_bouquets"]?></span></a></li>
						           	<?php }
						        	if (hasPermissions("adv", "channel_order")) { ?>
						        	<li><a href="./channel_order.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-info"></i><span>Order Channels</span></a></li>
									<li>
									<a href="#"><span>Categories</span><span class="arrow-right"></span></a>
						        	<?php 
						        	if (hasPermissions("adv", "add_cat")) { ?>
						        	<li><a href="./stream_category.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-plus"></i><span>Add Categorie</span></a></li>
									<?php }
						        	if (hasPermissions("adv", "categories")) { ?>
						        	<li><a href="./stream_categories.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-list-ul"></i><span>Manage <?=$_["categories"]?></span></a></li>
									</li>
									 <li>
									<a href="#"><span>Users</span><span class="arrow-right"></span></a>
									<?php } if (hasPermissions("adv", "add_reguser")) { ?>
                                    <li><a href="./reg_user.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-plus"></i><span>Add User</span></a></li>
									<?php }
									if (hasPermissions("adv", "mng_regusers")) { ?>
                                    <li><a href="./reg_users.php" style="padding-left:12%; font-size:15px;"><i class="far fa-handshake"></i><span>Manage Users</span></a></li>
							        <?php }
							        if (hasPermissions("adv", "mng_groups")) { ?>
							        <li><a href="./groups.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-users"></i><span>Manage Users <?=$_["groups"]?></span></a></li>							      
							        <?php }
							        if (hasPermissions("adv", "subresellers")) { ?>
							        <li><a href="./subresellers.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-plus"></i><span>Add <?=$_["subresellers"]?></span></a></li>		
							        <?php }
							        if (hasPermissions("adv", "mng_packages")) { ?>
							        <li><a href="./packages.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-stream"></i><span>Manage <?=$_["packages"]?></span></a></li>
									<?php } ?>
                                    </li>
									
								    <li>
							        <a href="#"><span>Security</span><span class="arrow-right"></span></a>
									<?php 
									if (hasPermissions("adv", "block_ips")) { ?>
									<a href="./ips.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-ban"></i><span><?=$_["blocked_ips"]?></span></a>
									<?php }
     		                       if (hasPermissions("adv", "block_isps")) { ?>
									<a href="./isps.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-lock"></i><span><?=$_["blocked_isps"]?></span></a>
									<?php }
									if (hasPermissions("adv", "block_uas")) { ?>
									<a href="./useragents.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-user-lock"></i><span><?=$_["blocked_uas"]?></span></a>
							        </li>
                                    <?php } ?>
										
				

								    <li>
							        <a href="#"><span>Tools</span><span class="arrow-right"></span></a>
							<?php 
							if (hasPermissions("adv", "epg")) { ?>
							<a href="./epgs.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-sync-alt"></i><span><?=$_["epgs"]?></span></a>
							<?php }
							if (hasPermissions("adv", "rtmp")) { ?>
							<a href="./rtmp_ips.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-check-double"></i><span><?=$_["rtmp_ips"]?></span></a>
							<?php }
							if (hasPermissions("adv", "tprofiles")) { ?>
							<a href="./profiles.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-file-video"></i><span><?=$_["transcode_profiles"]?></span></a>
							<?php }
							if (hasPermissions("adv", "mass_delete")) { ?>
							<a href="./mass_delete.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-radiation-alt"></i><span><?=$_["mass_delete"]?></span></a>
							<?php }
							if (hasPermissions("adv", "folder_watch")) { ?>
							<a href="./watch.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-folder-open"></i><span><?=$_["folder_watch"]?></span></a>
							<?php }
							if (hasPermissions("adv", "process_monitor")) { ?>
							<a href="./process_monitor.php?server=<?=$_INFO["server_id"]?>" style="padding-left:12%; font-size:15px;"><i class="fas fa-chalkboard"></i><span><?=$_["process_monitor"]?></span></a>
							<?php }
							if ($rPermissions["is_admin"]) { ?>
							<a href="./aappmy.php" style="padding-left:12%; font-size:15px;"><i class="fab fa-product-hunt"></i><span>phpmyadmin</span></a>							        </li>
                               <?php } ?>
									
								    <li>
							        <a href="#"><span>Logs</span><span class="arrow-right"></span></a>
									<?php }
									if (hasPermissions("adv", "client_request_log")) { ?>
                                    <a href="./client_logs.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-info"></i><span><?=$_["client_logs"]?></span></a>
									<?php }
									if (hasPermissions("adv", "connection_logs")) { ?>
                                    <a href="./user_activity.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-eye"></i><span><?=$_["activity_logs"]?></span></a>
									<?php }
									if (hasPermissions("adv", "reg_userlog")) { ?>
                                    <a href="./reg_user_logs.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-info"></i><span><?=$_["reseller_logs"]?></span></a>
									<?php }
									if (hasPermissions("adv", "stream_errors")) { ?>
                                    <a href="./stream_logs.php" style="padding-left:12%; font-size:15px;"><i class="far fa-file-video"></i><span><?=$_["stream_logs"]?></span></a>
									<?php }
									if (hasPermissions("adv", "manage_events")) { ?>
                                    <a href="./mag_events.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-binoculars"></i><span><?=$_["mag_event_logs"]?></span></a>
									<?php }
									if (hasPermissions("adv", "credits_log")) { ?>
                                    <a href="./credit_logs.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-dollar-sign"></i><span><?=$_["credit_logs"]?></span></a>
							</li>
                               <?php } ?>
                            </li>
                            <?php }
							}
                            if (($rPermissions["is_reseller"]) && ($rPermissions["reset_stb_data"])) { ?>
                            <li>
                                <a href="#"><span><?=$_["content"]?></span><span class="arrow-right"></span></a>
                                    <a href="./streams.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-play-circle"></i><span><?=$_["streams"]?></a>
                                    <a href="./movies.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-film"></i><span><?=$_["movies"]?></a>
                                    <a href="./series.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-video"></i><span><?=$_["series"]?></a>
                                    <a href="./episodes.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-fast-forward"></i><span><?=$_["episodes"]?></a>
                                    <a href="./radios.php" style="padding-left:12%; font-size:15px;"><i class="fas fa-broadcast-tower"></i><span><?=$_["stations"]?></a>
                            </li>
                            <?php } ?>
                        </ul>
                    </div>
                    <!-- End Sidebar -->
                    <div class="clearfix"></div>
                </div>
                <!-- Sidebar -left -->
            </div>