<?php
include "session.php"; include "functions.php";
$nabillangues = Array("" => "Default - EN", "fr" => "French", "es" => "Spanich", "it" => "Italian", "pt" => "Portuguese");

if (isset($_POST["submit_profile"])) {
	if ((strlen($_POST["password"]) < intval($rAdminSettings["pass_length"])) && (intval($rAdminSettings["pass_length"]) > 0)) {
		$_STATUS = 1;
	}
	if (((strlen($_POST["email"]) == 0) OR (!filter_var($_POST["email"], FILTER_VALIDATE_EMAIL))) && (($rAdminSettings["change_own_email"]) OR ($rPermissions["is_admin"]))) {
		$_STATUS = 2;
	}
	if ((strlen($_POST["reseller_dns"]) > 0) && (!filter_var("http://".$_POST["reseller_dns"], FILTER_VALIDATE_URL))) {
		$_STATUS = 3;
	}
	if (isset($_POST["sidebar"])) {
        $rSidebar = true;
    } else {
        $rSidebar = false;
    }
	if (isset($_POST["dark_mode"])) {
        $rDarkMode = true;
    } else {
        $rDarkMode = false;
    }
	if (isset($_POST["expanded_sidebar"])) {
        $rExpanded = true;
    } else {
        $rExpanded = false;
    }
	if (isset($_POST["sidebarbru"])) {
        $rSidebarbru = true;
        $rExpanded = true;
        $rSidebar = true;
    } else {
        $rSidebarbru = false;
    }

    if ($rPermissions["is_admin"]) {
	if (isset($_POST["jsmess"])) {
        $rjsmess = true;
    } else {
        $rjsmess = false;
    }
        $db->query("UPDATE `settings` SET `jsmess` = '" . intval($rjsmess) . "';");
    }
    if (!isset($_STATUS)) {
		if ((strlen($_POST["password"]) > 0) && (($rAdminSettings["change_own_password"]) OR ($rPermissions["is_admin"]))) {
			$rPassword = cryptPassword($_POST["password"]);
		} else {
			$rPassword = $rUserInfo["password"];
		}
        if (($rAdminSettings["change_own_email"]) OR ($rPermissions["is_admin"])) {
            $rEmail = $_POST["email"];
        } else {
            $rEmail = $rUserInfo["email"];
        }
        if (($rAdminSettings["change_own_dns"]) OR ($rPermissions["is_admin"])) {
            $rDNS = $_POST["reseller_dns"];
        } else {
            $rDNS = $rUserInfo["reseller_dns"];
        }
        if (($rAdminSettings["change_own_lang"]) OR ($rPermissions["is_admin"])) {

            $bob = $_POST["default_lang"];
		} else {
			$bob = $rUserInfo["default_lang"];
		}
    
        if (($_POST['port_admin'] == 8443) OR ($_POST['port_admin'] == $rServers[$_INFO["server_id"]]["http_broadcast_port"]) OR ($_POST['port_admin'] == $rServers[$_INFO["server_id"]]["https_broadcast_port"]) OR ($_POST['port_admin'] == $rServers[$_INFO["server_id"]]["rtmp_port"])) {
            $portadmin = $rSettings["port_admin"];
            if (file_exists('/etc/letsencrypt/live'))
        {
              header("Location: https://".$_SERVER['SERVER_NAME'].":".$rSettings["port_admin"]."/edit_profile.php?errorport"); 
                      exit;
        } 
        else 
        {
              header("Location: http://".$_SERVER['SERVER_ADDR'].":".$rSettings["port_admin"]."/edit_profile.php?errorport"); 
                      exit;
        }
        }
        else{																																																																							 
       if (isset($_POST['port_admin']) && $rPermissions["is_admin"] && ($_POST['port_admin'] != $rSettings["port_admin"]) && ( strlen($_POST["port_admin"]) > 0))  {
        $portadmin = $_POST["port_admin"];
        if (file_exists('/etc/letsencrypt/live')) {
		     exec("sed -i 's/listen ".$rSettings["port_admin"]." ssl;/listen ".intval($_POST["port_admin"])." ssl;/g' /home/xtreamcodes/iptv_xtream_codes/nginx/conf/nginx.conf");
        }
        else {
        exec("sed -i 's/listen ".$rSettings["port_admin"].";/listen ".intval($_POST["port_admin"]).";/g' /home/xtreamcodes/iptv_xtream_codes/nginx/conf/nginx.conf");
        }
        if ($rSettings["is_ufw"] == 1) {
             exec("sudo ufw allow ".intval($_POST["port_admin"])." && sudo ufw delete allow ".$rSettings["port_admin"]."");
        }
	     	 exec("sudo /home/xtreamcodes/iptv_xtream_codes/nginx/sbin/nginx -s reload");
             sleep(1);
        }
       else {
                   $portadmin = $rSettings["port_admin"];
       }
 		$db->query("UPDATE `settings` SET `port_admin` = '".ESC($portadmin)."';");
    } 
       
if ($rPermissions["is_admin"]) {
     if ((isset($_POST['is_ufw']) != $rSettings["is_ufw"]) && ( isset($_POST['is_ufw']) != true)) {
	     foreach (array_keys($rServers) as $rServerID) {
                  $isufw = false;
         			sexec($rServerID, "sudo ufw disable");
                }
	        }
     elseif ((isset($_POST['is_ufw']) != $rSettings["is_ufw"]) && ( isset($_POST['is_ufw']) != false)) {
	     foreach (array_keys($rServers) as $rServerID) {
                  $isufw = true;
	                 
                  if ($rServerID != $_INFO["server_id"]) {
                        sexec($rServerID, "sudo ufw disable && sudo echo y | sudo ufw reset && sudo ufw default deny incoming && sudo ufw default allow outgoing && sudo ufw allow " . $rServers[$rServerID]["ssh_port"] . " && sudo ufw allow from  " . $_SERVER["SERVER_ADDR"] . " && sudo ufw allow " . $rServers[$rServerID]["http_broadcast_port"] . " && sudo ufw allow " . $rServers[$rServerID]["https_broadcast_port"] . " && sudo ufw allow " . $rServers[$rServerID]["rtmp_port"] . " && sudo echo y | sudo ufw enable");
                    } else {
                        exec("sudo ufw disable && sudo echo y | sudo ufw reset && sudo ufw default deny incoming && sudo ufw default allow outgoing && sudo ufw allow " . $rServers[$rServerID]["ssh_port"] . " && sudo ufw allow " . $rSettings["port_admin"] . " && sudo ufw allow 8443 && sudo ufw allow " . $rServers[$rServerID]["http_broadcast_port"] . " && sudo ufw allow " . $rServers[$rServerID]["https_broadcast_port"] . " && sudo ufw allow " . $rServers[$rServerID]["rtmp_port"] . "");
                            foreach (array_keys($rServers) as $rServerID) {
                        exec("sudo ufw allow from " . $rServers[$rServerID]["server_ip"] . " && sudo ufw delete allow from " . $_SERVER["SERVER_ADDR"] . " && sudo echo y | sudo ufw enable");
                        }
                    }
                }
            }
     else {
        $isufw = $rSettings["is_ufw"];
    }
        $db->query("UPDATE `settings` SET `is_ufw` = '" . intval($isufw) . "';");
}

		$db->query("UPDATE `reg_users` SET `password` = '".ESC($rPassword)."', `email` = '".ESC($rEmail)."', `reseller_dns` = '".ESC($rDNS)."', `default_lang` = '".ESC($bob)."', `dark_mode` = ".intval($rDarkMode).", `sidebar` = ".intval($rSidebar).", `expanded_sidebar` = ".intval($rExpanded).", `sidebarbru` = ".intval($rSidebarbru)." WHERE `id` = ".intval($rUserInfo["id"]).";");
        $rUserInfo = getRegisteredUser($rUserInfo["id"]);
		$rAdminSettings["dark_mode"] = $rUserInfo["dark_mode"];
		$rAdminSettings["expanded_sidebar"] = $rUserInfo["expanded_sidebar"];
		$rSettings["sidebar"] = $rUserInfo["sidebar"];
		$rSettings["sidebarbru"] = $rUserInfo["sidebarbru"];
        
    if ($rPermissions["is_admin"]) {
       if (file_exists('/etc/letsencrypt/live')) {

              header("Location: https://".$_SERVER['SERVER_NAME'].":".$_POST["port_admin"]."/edit_profile.php?successedit"); 
                      exit;
        } 
        else 
        {
              header("Location: http://".$_SERVER['SERVER_ADDR'].":".$_POST["port_admin"]."/edit_profile.php?successedit"); 
                      exit;
        }
    }
    elseif ($rPermissions["is_reseller"]) {
        if (file_exists('/etc/letsencrypt/live'))
        {
              header("Location: https://".$_SERVER['SERVER_NAME'].":".$rSettings["port_admin"]."/edit_profile.php?successedit"); 
                      exit;
        } 
        else 
        {
              header("Location: http://".$_SERVER['SERVER_ADDR'].":".$rSettings["port_admin"]."/edit_profile.php?successedit"); 
                      exit;
        }
      }
    }
} 
if(isset($_GET['successedit'])){
	$_STATUS = 0;
}
if(isset($_GET['errorport'])){
$_STATUS = 4;
}

if  ($rSettings["sidebar"] && $rUserInfo["sidebarbru"]) {
    include "header_sidebarbru.php";
}  
elseif ($rSettings["sidebar"]) {
    include "header_sidebar.php";
} 
else {
    include "header.php";
}
        if ($rSettings["sidebar"]) { ?>
        <div class="content-page"><div class="content boxed-layout"><div class="container-fluid">
        <?php } else { ?>
        <div class="wrapper boxed-layout"><div class="container-fluid">
        <?php } ?>
                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box">
                            <h4 class="page-title"><?=$_["profile"]?></h4>
                        </div>
                    </div>
                </div>     
                <!-- end page title --> 
                <div class="row">
                    <div class="col-xl-12">
                        <?php if ((isset($_STATUS)) && ($_STATUS == 0)) { if (!$rSettings["jsmess"]) { ?>
                          <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <?=$_["profile_success"]?>
                        </div>
                       <?php } else { ?>
                    <script type="text/javascript">
  					swal("", '<?=$_["profile_success"]?>', "success");
  					</script>
                     <?php } } else if ((isset($_STATUS)) && ($_STATUS == 1)) { if (!$rSettings["jsmess"]) { ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <?=str_replace("{num}", $rAdminSettings["pass_length"], $_["profile_fail_1"])?>
                        </div>
                       <?php } else { ?>
                    <script type="text/javascript">
  					swal("", '<?=str_replace("{num}", $rAdminSettings["pass_length"], $_["profile_fail_1"])?>', "warning");
  					</script>
                     <?php } } else if ((isset($_STATUS)) && ($_STATUS == 2)) { if (!$rSettings["jsmess"]) { ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <?=$_["profile_fail_2"]?>
                        </div>
                       <?php } else { ?>
                    <script type="text/javascript">
  					swal("", '<?=$_["profile_fail_2"]?>', "warning");
  					</script>
                     <?php } } else if ((isset($_STATUS)) && ($_STATUS == 3)) { if (!$rSettings["jsmess"]) { ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <?=$_["profile_fail_3"]?>
                        </div>
                       <?php } else { ?>
                    <script type="text/javascript">
  					swal("", '<?=$_["profile_fail_3"]?>', "warning");
  					</script>
                     <?php } } else if ((isset($_STATUS)) && ($_STATUS == 4)) { if (!$rSettings["jsmess"]) { ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            This port already in use, choose another one.
                        </div>
                       <?php } else { ?>
                    <script type="text/javascript">
  					swal("", "This port already in use, choose another one.", "warning");
  					</script>
                     <?php } } ?>     
                        <div class="card">
                            <div class="card-body">
                                <form action="./edit_profile.php" method="POST" id="edit_profile_form" data-parsley-validate="">
                                    <div id="basicwizard">
                                        <ul class="nav nav-pills bg-light nav-justified form-wizard-header mb-4">
                                            <li class="nav-item">
                                                <a href="#user-details" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2"> 
                                                    <i class="mdi mdi-account-card-details-outline mr-1"></i>
                                                    <span class="d-none d-sm-inline"><?=$_["details"]?></span>
                                                </a>
                                            </li>
                                        </ul>
                                        <div class="tab-content b-0 mb-0 pt-0">
                                            <div class="tab-pane" id="user-details">
                                                <div class="row">
                                                    <div class="col-12">
                                                        <div class="form-group row mb-4">
                                                            <label class="col-md-4 col-form-label" for="username"><?=$_["username"]?></label>
                                                            <div class="col-md-8">
                                                                <input type="text" class="form-control" id="username" name="username" value="<?=htmlspecialchars($rUserInfo["username"])?>" readonly>
                                                            </div>
                                                        </div>
                                                        <?php if (($rPermissions["is_admin"]) OR ($rAdminSettings["change_own_password"])) { ?>
                                                        <div class="form-group row mb-4">
                                                            <label class="col-md-4 col-form-label" for="password"><?=$_["change_password"]?></label>
                                                            <div class="col-md-8">
                                                                <input type="text" class="form-control" id="password" name="password" value="">
                                                            </div>
                                                        </div>
                                                        <?php }
                                                        if ($rPermissions["is_admin"]) { ?>
                                                        <div class="form-group row mb-4">
                                                            <label class="col-md-4 col-form-label" for="port_admin">Admin Port</label>
                                                            <div class="col-md-8">
                                                                <input type="text" id="port_admin" class="form-control" name="port_admin" value="<?=htmlspecialchars($rSettings["port_admin"])?>" required data-parsley-trigger="change">
                                                            </div>
                                                        </div>
														<?php }                                                        
                                                    
                                                        if (($rPermissions["is_admin"]) OR ($rAdminSettings["change_own_email"])) { ?>
                                                        <div class="form-group row mb-4">
                                                            <label class="col-md-4 col-form-label" for="email"><?=$_["email_address"]?></label>
                                                            <div class="col-md-8">
                                                                <input type="email" id="email" class="form-control" name="email" required value="<?=htmlspecialchars($rUserInfo["email"])?>" required data-parsley-trigger="change">
                                                            </div>
                                                        </div>
														<?php }
                                                        if (($rPermissions["is_reseller"]) && ($rAdminSettings["change_own_dns"])) { ?>
                                                        <div class="form-group row mb-4">
                                                            <label class="col-md-4 col-form-label" for="reseller_dns"><?=$_["reseller_dns"]?></label>
                                                            <div class="col-md-8">
                                                                <input type="text" class="form-control" id="reseller_dns" name="reseller_dns" value="<?=htmlspecialchars($rUserInfo["reseller_dns"])?>">
                                                            </div>
                                                        </div>
                                                        <?php }
                                                        if (($rPermissions["is_admin"]) OR ($rAdminSettings["change_own_lang"])) { ?>
                                                    <div class="form-group row mb-4">
                                                            <label class="col-md-4 col-form-label" for="default_lang">UI Language</label>
                                                            <div class="col-md-8">
                                                                 <select type="default_lang" name="default_lang" id="default_lang" class="form-control" data-toggle="select2">
                                                                    <?php foreach ($nabillangues as $rKey => $rLanguage) { ?>
                                                                    <option<?php if ($rUserInfo["default_lang"] == $rKey) { echo " selected"; } ?> value="<?=$rKey?>"><?=$rLanguage?></option>
                                                                 <?php } ?>    
                                                            </select>
                                                            </div>
                                                        </div>  
														<?php } ?>
														<div class="form-group row mb-4">
															<label class="col-md-4 col-form-label" for="sidebar"><?=$_["sidebar_nav"]?></label>
                                                            <div class="col-md-2">
                                                                <input name="sidebar" id="sidebar" type="checkbox"<?php if ($rUserInfo["sidebar"] == 1) { echo "checked "; } ?>data-plugin="switchery" class="js-switch" data-color="#039cfd"/>
                                                            </div>
															<label class="col-md-4 col-form-label" for="expanded_sidebar"><?=$_["expanded_sidebar"]?></label>
                                                            <div class="col-md-2">
                                                                <input name="expanded_sidebar" id="expanded_sidebar" type="checkbox"<?php if ($rUserInfo["expanded_sidebar"] == 1) { echo "checked "; } ?>data-plugin="switchery" class="js-switch" data-color="#039cfd"/>
                                                            </div>
                                                        </div>
                                                           <div class="form-group row mb-4">
			                                                 <label class="col-md-4 col-form-label" for="sidebarbru">brutus style</label>
                                                            <div class="col-md-2">
                                                                <input name="sidebarbru" id="sidebarbru" type="checkbox"<?php if ($rUserInfo["sidebarbru"] == 1) { echo "checked "; } ?>data-plugin="switchery" class="js-switch" data-color="#039cfd"/>
                                                            </div>
														<?php
                                                             if ($rPermissions["is_admin"]) { ?>                                                        
															<label class="col-md-4 col-form-label" for="dark_mode"><?=$_["dark_mode"]?></label>
                                                            <div class="col-md-2">
                                                                <input name="dark_mode" id="dark_mode" type="checkbox"<?php if ($rUserInfo["dark_mode"] == 1) { echo "checked "; } ?>data-plugin="switchery" class="js-switch" data-color="#039cfd"/>
                                                            </div>
                                                        </div>
                                                          <?php }
                                                             if ($rPermissions["is_admin"]) { ?>  
                                                           <div class="form-group row mb-4">
			                                                 <label class="col-md-4 col-form-label" for="jsmess">Brutus jsmess</label>
                                                            <div class="col-md-2">
                                                                <input name="jsmess" id="jsmess" type="checkbox"<?php if ($rSettings["jsmess"] == 1) { echo "checked "; } ?>data-plugin="switchery" class="js-switch" data-color="#039cfd"/>
                                                            </div>
			                                                 <label class="col-md-4 col-form-label" for="is_ufw">Active UFW</label>
                                                            <div class="col-md-2">
                                                                <input name="is_ufw" id="is_ufw" type="checkbox"<?php if ($rSettings["is_ufw"] == 1) { echo "checked "; } ?>data-plugin="switchery" class="js-switch" data-color="#039cfd"/>
                                                            </div>
                                                        </div>
                                                        <?php } ?>
                                                        </div> <!-- end col -->
                                                </div> <!-- end row -->
                                                <ul class="list-inline wizard mb-0">
                                                    <li class="list-inline-item float-right">
                                                        <input name="submit_profile" type="submit" class="btn btn-primary" value="<?=$_["save_profile"]?>" />
                                                        </li>
                                                </ul>
                                            </div>
                                        </div> <!-- tab-content -->
                                    </div> <!-- end #basicwizard-->
                                </form>

                            </div> <!-- end card-body -->
                        </div> <!-- end card-->
                    </div> <!-- end col -->
                </div>
            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->
        <?php if ($rSettings["sidebar"]) { echo "</div>"; } ?>
        <!-- Footer Start -->
        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 copyright text-center"><?=getFooter()?></div>
                </div>
            </div>
            </footer>
        <!-- end Footer -->

        <script src="assets/js/vendor.min.js"></script>
        <script src="assets/libs/jquery-toast/jquery.toast.min.js"></script>
        <script src="assets/libs/jquery-nice-select/jquery.nice-select.min.js"></script>
        <script src="assets/libs/switchery/switchery.min.js"></script>
        <script src="assets/libs/select2/select2.min.js"></script>
        <script src="assets/libs/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
        <script src="assets/libs/bootstrap-maxlength/bootstrap-maxlength.min.js"></script>
        <script src="assets/libs/jquery-tabledit/jquery.tabledit.min.js"></script>
        <script src="assets/libs/clockpicker/bootstrap-clockpicker.min.js"></script>
        <script src="assets/libs/moment/moment.min.js"></script>
        <script src="assets/libs/daterangepicker/daterangepicker.js"></script>
        <script src="assets/libs/twitter-bootstrap-wizard/jquery.bootstrap.wizard.min.js"></script>
        <script src="assets/libs/treeview/jstree.min.js"></script>
        <script src="assets/js/pages/treeview.init.js"></script>
        <script src="assets/js/pages/form-wizard.init.js"></script>
        <script src="assets/js/pages/form-remember.js"></script>
        <script src="assets/libs/parsleyjs/parsley.min.js"></script>
        <script src="assets/js/app.min.js"></script>
        
        <script>
        (function($) {
          $.fn.inputFilter = function(inputFilter) {
            return this.on("input keydown keyup mousedown mouseup select contextmenu drop", function() {
              if (inputFilter(this.value)) {
                this.oldValue = this.value;
                this.oldSelectionStart = this.selectionStart;
                this.oldSelectionEnd = this.selectionEnd;
              } else if (this.hasOwnProperty("oldValue")) {
                this.value = this.oldValue;
                this.setSelectionRange(this.oldSelectionStart, this.oldSelectionEnd);
              }
            });
          };
        }(jQuery));
        
        $(document).ready(function() {
            $('select.select2').select2({width: '100%'})
            var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
            elems.forEach(function(html) {
              var switchery = new Switchery(html);
            });
            
            $(document).keypress(function(event){
                if(event.which == 13 && event.target.nodeName != "TEXTAREA") return false;
            });
            
            $("form").attr('autocomplete', 'off');

            formCache.init();
        });

        $(window).bind('beforeunload', function() {
            formCache.save();
        });
        </script>
    </body>
</html>